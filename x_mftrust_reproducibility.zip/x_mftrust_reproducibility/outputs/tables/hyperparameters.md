| parameter          | candidates          |   selected |
|:-------------------|:--------------------|-----------:|
| learning_rate      | 5e-5;1e-4;2e-4      |     0.0001 |
| batch_size         | 8;16;32             |    16      |
| weight_decay       | 1e-5;1e-4;1e-3      |     0.0001 |
| embedding_dim      | 128;256;384         |   256      |
| attention_heads    | 4;8;12              |     8      |
| hcmtf_layers       | 2;4;6               |     4      |
| dropout            | 0.1;0.2;0.3         |     0.2    |
| uncertainty_weight | 0.1;0.2;0.3;0.4;0.5 |     0.3    |
| epochs             | 100;150;200         |   150      |