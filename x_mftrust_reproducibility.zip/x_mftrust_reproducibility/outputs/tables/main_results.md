| method                          |   precision |   recall |   map50 |    f1 |
|:--------------------------------|------------:|---------:|--------:|------:|
| RGB baseline                    |       0.801 |    0.774 |   0.789 | 0.787 |
| Conventional multimodal fusion  |       0.85  |    0.818 |   0.836 | 0.834 |
| Transformer multimodal baseline |       0.873 |    0.839 |   0.858 | 0.856 |
| X-MFTrust                       |       0.891 |    0.858 |   0.883 | 0.874 |