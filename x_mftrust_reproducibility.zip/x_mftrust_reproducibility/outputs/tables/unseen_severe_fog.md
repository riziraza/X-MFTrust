| method                  |   precision |   recall |   map50 |    f1 |
|:------------------------|------------:|---------:|--------:|------:|
| RGB baseline            |       0.748 |    0.696 |   0.736 | 0.721 |
| Conventional multimodal |       0.774 |    0.738 |   0.761 | 0.756 |
| Transformer multimodal  |       0.801 |    0.761 |   0.786 | 0.78  |
| X-MFTrust               |       0.824 |    0.784 |   0.811 | 0.803 |